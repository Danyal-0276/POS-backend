const CustomerProfileRepository = require('../repository/customerProfile.repository');
const ApiError = require('../../../modules/ApiError'); 

class CustomerProfileService {
  static async create(userId, body, filePath) {
    const exists = await CustomerProfileRepository.findByUserId(userId);
    if (exists) throw new ApiError(409, 'Profile already exists');

    const doc = { userId, ...body };

    if (filePath) doc.profilePicture = filePath;
    return CustomerProfileRepository.create(doc);
  }

  static async get(reqObj) {
    let results = "";
    const profile = await CustomerProfileRepository.findByUserId(reqObj);
    let { userId , ...rest } = profile;
    
    results = {

      name : userId?.name,
      email : userId?.email,
      userId : userId?._id,
      ...rest

    }
    
    if (!profile) throw new ApiError(404, 'Profile not found');
    return results;
  }

  static async update(userId, body, filePath) {
    if (filePath) body.profilePicture = filePath;
    const updated = await CustomerProfileRepository.updateByUserId(userId, body);
    if (!updated) throw new ApiError(404, 'Profile not found');
    return updated;
  }

  static delete(userId) {
    return CustomerProfileRepository.deleteByUserId(userId);
  }

 
   static async exists(userId) {
 
    const id = typeof userId === 'string' ? new mongoose.Types.ObjectId(userId) : userId;

 
    let doc = await CustomerProfileRepository.findByUserId(id);


    if (!doc) {
      doc = await CustomerProfileRepository.findRaw({ userId: String(id) });
    }

    if (!doc) {
      console.warn('[CustomerProfile.exists] not found for', { id, typeofId: typeof id });
    }
    return !!doc;
  }

    static async getCustomerProfile(data){
      try {
          let results = "";
          console.log(data);
          if(data == null){
            return "Customer Id is required";
          }
          results = await CustomerProfileRepository.findById(data);
          if(results == null){
            return {status : 200 , message : "Profile have not been set"};
          }
          return {status : 200 , message : "Customer Found" , result : results};
      } catch (error) {
        throw error;
      }
    }
}

module.exports = CustomerProfileService;
