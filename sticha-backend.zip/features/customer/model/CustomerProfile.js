'use strict';
const mongoose = require('mongoose');

const CustomerProfileSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', unique: true },
    profilePicture: String,
    phone: String,
    address: String,
    geoLocation: {
      type: { type: String, enum: ['Point'], default: 'Point' },
      coordinates: [Number]
    },
    measurements: {
      type: Map,
      of: String
    }
  },
  { timestamps: true }
);

CustomerProfileSchema.index({ geoLocation: '2dsphere' });

module.exports = mongoose.model('CustomerProfile', CustomerProfileSchema);
