const CustomerProfile = require('../model/CustomerProfile');

class CustomerProfileRepository {
  static create(doc) {
    return CustomerProfile.create(doc);
  }

    static async findById(userId){
      console.log(userId);
      return CustomerProfile.findOne({ userId : userId}).lean().exec();
    }
  

  static findByUserId(userId) {
    return CustomerProfile.findOne({ userId }).populate('userId').lean().exec();
  }

  static updateByUserId(userId, upd) {
    return CustomerProfile.findOneAndUpdate({ userId }, upd, { new: true, lean: true }).exec();
  }

  static deleteByUserId(userId) {
    return CustomerProfile.findOneAndDelete({ userId }).exec();
  }

   static findRaw(filter) {
      return CustomerProfile.findOne(filter).lean().exec();
    }
}

module.exports = CustomerProfileRepository;
