const express = require('express');
const router = express.Router();

const upload = require('../../../middlewares/upload.middleware');
const validate = require('../../../middlewares/validate.middleware');
const checkRoles = require('../../../middlewares/rolecheck.middleware');

const schema = require('../validation/customerProfile.validation');
const CustomerProfileService = require('../service/customerProfileService');
const parseMeasurements = require('../../../middlewares/parseMeasurements.middleware');
const asyncHandler = require('../../../middlewares/asyncHandler');

// CREATE
router.post(
  '/',
  checkRoles('customer'),
  upload.avatarUpload,
  parseMeasurements,
  validate(schema.createProfile),
  async (req, res, next) => {
    try {
      const filePath = req.file ? `${req.file.filename}` : undefined;
      const profile = await CustomerProfileService.create(req.user.user, req.body, filePath);
      res.status(201).json({ status: 201, result: profile });
    } catch (e) {
      next(e);
    }
  }
);

// READ
router.get('/', checkRoles('customer'), async (req, res, next) => {
  try {
    console.log("here");
    const profile = await CustomerProfileService.get(req.user.user);
    res.json({ status: 200, result: profile });
  } catch (e) {
    next(e);
  }
});

// UPDATE
router.put(
  '/',
  checkRoles('customer'),
  upload.single('profilePicture'),
  parseMeasurements,
  validate(schema.updateProfile),
  async (req, res, next) => {
    try {
      const filePath = req.file ? `${req.file.filename}` : undefined;
      const profile = await CustomerProfileService.update(req.user._id, req.body, filePath);
      res.json({ status: 200, result: profile });
    } catch (e) {
      next(e);
    }
  }
);

// DELETE
router.delete('/',  checkRoles('customer') ,async (req, res, next) => {
  try {
    await CustomerProfileService.delete(req.user._id);
    res.json({ status: 200, message: 'Profile deleted' });
  } catch (e) {
    next(e);
  }
});

router.get('/profile/:id', asyncHandler(async (req, res) => {
  const result = await CustomerProfileService.getCustomerProfile(req.params.id);
  res.status(201).json(result);
}));


module.exports = router;
