const Joi = require('joi');

const geoSchema = Joi.object({
  coordinates: Joi.array().items(Joi.number()).length(2).required()
});

const measurementsSchema = Joi.object().pattern(Joi.string(), Joi.string());

exports.createProfile = Joi.object({
  phone: Joi.string().trim().required(),
  address: Joi.string().trim().required(),
  geoLocation: geoSchema,
  measurements: measurementsSchema
});

exports.updateProfile = Joi.object({
  phone: Joi.string().trim(),
  address: Joi.string().trim(),
  geoLocation: geoSchema,
  measurements: measurementsSchema
}).min(1); // at least one field
