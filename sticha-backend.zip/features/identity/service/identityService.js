const RoleService = require('../../role/services/RoleService');
const { UserService } = require('../../user/services/UserService');
const bcrypt = require('bcrypt');
const { haspassword, sendEmail } = require('../../../modules/helper');
const { exist } = require('joi');
const redis = require('../../../config/redis');
const { result } = require('lodash');

class IdentityService {
    static async register(data) {
        try {
            const { role, password, ...rest } = data;

            const newRole = await RoleService.verifyRole(role);
            if (!newRole) {
                return { status: 404, message: 'Role not found' };
            }

            const hashedPassword = await haspassword(password);

            delete data.role;
            delete data.password;

            data.roleId = newRole._id;
            data.password = hashedPassword;

            const createdUser = await UserService.addUser(data);

            if (createdUser?._id) {
                const otp = Math.floor(100000 + Math.random() * 900000).toString(); 

              

                sendEmail({
                    from: '"Sticha Support" <notifications.vmeals@gmail.com>',
                    to: createdUser.email,
                    subject: 'Your OTP Code',
                    html: `
          <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Security Code from Sticha Support</title>
    <style>
        @media only screen and (max-width: 600px) {
            .container {
                width: 95% !important;
            }
            .header {
                padding: 20px 10px !important;
            }
            .content {
                padding: 30px 15px !important;
            }
            .otp-code {
                font-size: 28px !important;
                padding: 15px 30px !important;
            }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f7f9fc;">
    <!-- Main container -->
    <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#f7f9fc">
        <tr>
            <td align="center">
                <!-- Content container -->
                <table class="container" width="600" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" style="margin: 30px auto; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
                    <!-- Header -->
                    <tr>
                        <td class="header" align="center" bgcolor="#2d3748" style="padding: 30px 0;">
                            <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Sticha Support</h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td class="content" style="padding: 40px 50px; color: #4a5568; line-height: 1.6;">
                            <h2 style="color: #2d3748; margin-top: 0;">Hi ${createdUser.name},</h2>
                            
                            <p style="margin-bottom: 25px;">Your One-Time Password (OTP) for account verification is:</p>
                            
                            <!-- OTP Display -->
                            <div class="otp-code" style="background-color: #f8fafc; border: 1px dashed #cbd5e0; 
                                display: inline-block; padding: 18px 40px; margin: 20px 0; 
                                font-size: 32px; font-weight: bold; letter-spacing: 3px; color: #2d3748;">
                                ${otp}
                            </div>
                            
                            <p style="margin-top: 25px; margin-bottom: 30px;">
                                This code is valid for <strong style="color: #e53e3e;">10 minutes</strong>. 
                                Please do not share this code with anyone for security reasons.
                            </p>
                            
                            <p style="margin-bottom: 5px;">If you didn't request this code, please ignore this email.</p>
                            
                            <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 30px 0;">
                            
                            <!-- Support Info -->
                            <p style="font-size: 14px; color: #718096; margin-bottom: 5px;">
                                Need assistance? Contact our support team at 
                                <a href="mailto:support@sticha.com" style="color: #4299e1; text-decoration: none;">support@sticha.com</a>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td bgcolor="#edf2f7" align="center" style="padding: 25px 0; font-size: 12px; color: #718096;">
                            <p style="margin: 5px 0;">© 2023 Sticha Support. All rights reserved.</p>
                            <p style="margin: 5px 0;">123 Business Street, Tech City, TC 10001</p>
                            <p style="margin: 5px 0;">
                                <a href="#" style="color: #4299e1; text-decoration: none; margin: 0 10px;">Privacy Policy</a> | 
                                <a href="#" style="color: #4299e1; text-decoration: none; margin: 0 10px;">Terms of Service</a>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `,
                });

               await redis.set(`otp:${createdUser.email}` , otp , {
                EX : 600
               });
            }

            return {
                name: createdUser.name,
                email: createdUser.email,
            };
        } catch (error) {
            console.error(error);
            throw error;
        }
    }

    static async verifyOtp(data){

        try {
            let result = "";
            let { email , otp} = data;
            let otpFromRedis = await redis.get(`otp:${email}`);
            
            
           
            if(otp && (otp === otpFromRedis)){
              result =  await UserService.markEmailVerified(email);
            } else{
                result = "OTP Expired";
            }  
            
            return result;
           
        } catch (error) {
            throw error;
        }

    }
    static async verifyIdentity(data){

        try {
            let result = await UserService.findUser(data);
       
            return result;           
        } catch (error) {
            throw error;
        }

    }

    static async verifyPassword(data){
        try {
            let result = "";
            let user = await UserService.findUser(data);
            result = user;
            return result;

        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async updateUserPassword(data){
        try {
            let result = "";
            let { new_password ,  email } = data;
            let hashpassword = await haspassword(new_password);
            let updatedpassword = await UserService.updatePassword({email , hashpassword}); 
            return updatedpassword;
        } catch (error) {
            throw error;
        }
    }



}

module.exports = IdentityService;
