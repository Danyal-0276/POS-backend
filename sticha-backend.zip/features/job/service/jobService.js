const redis = require('../../../config/redis');
const JobRepo = require('../repository/job.repository');
const PropRepo = require('../repository/proposal.repository');
const ApiError = require('../../../modules/ApiError');
const OrderService = require('../../order/service/orderService');

class JobService {
  /* ---------- Jobs ---------- */
  static async createJob(customerId, body, attachmentUrls) {
    const doc = { ...body, customerId, attachmentUrls };
    return JobRepo.create(doc);
  }

  static async listJobs(filter, pagination) {
    const key = `jobs:${JSON.stringify(filter)}:${pagination.page}:${pagination.limit}`;
    const cached = await redis.get(key);
    if (cached) return JSON.parse(cached);

    const [result, total] = await Promise.all([
      JobRepo.list(filter, pagination),
      JobRepo.count(filter)
    ]);

    await redis.setEx(key, 30, JSON.stringify({ total, result })); // 30 s cache
    return { total, result };
  }

  static async getJobWithAuth(jobId, user) {
    const job = await JobRepo.findById(jobId);
    if (!job) throw new ApiError(404, 'Job not found');

    // customers see own, tailors see any open job
    if (user.role !== 'customer' || String(job.customerId) === user._id) return job;

    throw new ApiError(403, 'Forbidden');
  }

  static async updateJob(jobId, customerId, body) {
    const job = await JobRepo.findById(jobId);
    if (!job || String(job.customerId) !== customerId) throw new ApiError(404, 'Job not found');
    if (job.status !== 'open') throw new ApiError(400, 'Job not editable');

    return JobRepo.update(jobId, body);
  }

  static async closeJob(jobId, customerId) {
    return this.updateJob(jobId, customerId, { status: 'closed' });
  }

  /* ---------- Proposals ---------- */
  static async submitProposal(jobId, tailorId, body) {


    const job = await JobRepo.findById(jobId);

    if (!job || job.status !== 'open') throw new ApiError(400, 'Job not open');
    const alreadyExits = await PropRepo.findByTailorId({ tailorId, jobId });
    console.log(alreadyExits);
    if (alreadyExits == null || alreadyExits.length === 0) {
      const doc = { ...body, jobId, tailorId };
      let results = await PropRepo.create(doc);
      return { status : 200 , message : "Created" , result: results}
    } else {
      return {status : 201 , message : "Already Applied"}
    }

  }

  static async listProposals(jobId, customerId) {

    let results = "";

    return await JobRepo.findById(jobId).then((job) => {
      if (!job || String(job.customerId) !== customerId)
        throw new ApiError(404, 'Job not found');
      return PropRepo.listByJob(jobId);
    });
  }

  static async acceptProposal(jobId, proposalId, customerId) {
    const job = await JobRepo.findById(jobId);
    if (!job || String(job.customerId) !== customerId)
      throw new ApiError(404, 'Job not found');
    if (job.status !== 'open') throw new ApiError(400, 'Job not open');

    const proposal = await PropRepo.findById(proposalId);
    if (!proposal || String(proposal.jobId) !== jobId)
      throw new ApiError(404, 'Proposal not found');

    // atomic accept
    await Promise.all([
      JobRepo.update(jobId, { status: 'closed', acceptedProposalId: proposalId }),
      PropRepo.update(proposalId, { status: 'accepted' }),
      PropRepo.rejectOtherProposals(jobId, proposalId)
    ]);

    // 2️⃣ create Order + escrow intent (transaction wraps inside)
    const order = await OrderService.createFromProposal({ job, proposal });
    // 3️⃣ optional: publish domain event
    // EventBus.publish('OrderCreated', order);

    return { jobId, proposalId, orderId: orderData.order._id, paymentUrl: orderData.approvalUrl };
  }
}

module.exports = JobService;
