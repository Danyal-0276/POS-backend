const express  = require('express');
const router   = express.Router();

const upload       = require('../../../middlewares/upload.middleware');
const validate     = require('../../../middlewares/validate.middleware');
const paginate     = require('../../../middlewares/pagination.middleware');
const checkRoles   = require('../../../middlewares/rolecheck.middleware');

const jobSchema    = require('../validation/job.validation');
const propSchema   = require('../validation/proposal.validation');
const Service      = require('../service/jobService');

/* ---------- Public job list ---------- */
router.get(
  '/',
  paginate(),
  async (req, res, next) => {
    try {
      const filter = {};
      if (req.query.categoryId) filter.categoryId = req.query.categoryId;
      if (req.query.search) filter.$text = { $search: req.query.search };
      const data = await Service.listJobs(filter, req.pagination);
      res.json({ status: 200, ...data });
    } catch (e) { next(e); }
  }
);

/* ---------- Customer routes ---------- */


/* create job */
router.post('/',
    checkRoles('customer'),
  upload.array('attachments', 5),
  validate(jobSchema.create),
  async (req, res, next) => {
    try {
      const urls = (req.files || []).map(f => f.filename);
      const job  = await Service.createJob(req.user.user, req.body, urls);
      res.status(201).json({ status: 201, result: job });
    } catch (e) { next(e); }
  }
);

/* list own jobs */
router.get('/mine',
    checkRoles('customer'),
  paginate(),
  async (req, res, next) => {
    try {
      const filter = { customerId: req.user.user };
      const data   = await Service.listJobs(filter, req.pagination);
      res.json({ status: 200, ...data });
    } catch (e) { next(e); }
  }
);

/* update / close / cancel */
router.put('/:id',
    checkRoles('customer'),
  validate(jobSchema.update),
  async (req, res, next) => {
    try {
      const job = await Service.updateJob(req.params.id, req.user.user, req.body);
      res.json({ status: 200, result: job });
    } catch (e) { next(e); }
  }
);

router.delete('/:id',
    checkRoles('customer'),
  async (req, res, next) => {
    try {
      await Service.updateJob(req.params.id, req.user.user, { status: 'cancelled' });
      res.json({ status: 200, message: 'Job cancelled' });
    } catch (e) { next(e); }
  }
);

/* list proposals for a job */
router.get('/:id/proposals',
    checkRoles('customer'),
  async (req, res, next) => {
    try {
      const list = await Service.listProposals(req.params.id, req.user.user);
      res.json({ status: 200, result: list });
    } catch (e) { next(e); }
  }
);

/* accept proposal */
router.post('/:id/proposals/:pid/accept', 
    checkRoles('customer'),
  async (req, res, next) => {
    try {
      const token = req.headers['authorization']?.split(' ')[1];
          const user = jwt.decode(token);
          const userId = user?.user;
      const result = await Service.acceptProposal(
        req.params.id, req.params.pid, req.user.user);
      res.json({ status: 200, result });
    } catch (e) { next(e); }
  }
);

/* ---------- Tailor routes ---------- */
router.post('/:id/proposals',
  checkRoles('tailor'),
  validate(propSchema.create),
  async (req, res, next) => {
    try {
      const prop = await Service.submitProposal(
        req.params.id, req.user.user, req.body);
      res.json(prop);
    } catch (e) { next(e); }
  }
);

module.exports = router;
