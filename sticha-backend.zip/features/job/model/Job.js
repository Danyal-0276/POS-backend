'use strict';
const mongoose = require('mongoose');

const JobSchema = new mongoose.Schema(
  {
    customerId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    categoryId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true, index: true },
    title:        { type: String, required: true, trim: true },
    description:  { type: String, required: true },
    budget:       { type: Number, min: 1 },
    dueDate:      { type: Date },
    attachmentUrls: [String],
    status:       { type: String, enum: ['open', 'closed', 'cancelled'], default: 'open', index: true },
    acceptedProposalId: { type: mongoose.Schema.Types.ObjectId, ref: 'Proposal', default: null },
    deletedAt:    { type: Date }
  },
  { timestamps: true }
);

JobSchema.index({ title: 'text', description: 'text' });

module.exports = mongoose.model('Job', JobSchema);
