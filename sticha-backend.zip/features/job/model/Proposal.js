'use strict';
const mongoose = require('mongoose');

const ProposalSchema = new mongoose.Schema(
  {
    jobId:     { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true, index: true },
    tailorId:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    quote:     { type: Number, required: true, min: 1 },
    duration:  { type: Number, required: true, min: 1 },  // days
    message:   { type: String, maxlength: 2000 },
    status:    { type: String, enum: ['submitted', 'accepted', 'rejected'], default: 'submitted' },
    deletedAt: { type: Date }
  },
  { timestamps: true }
);

ProposalSchema.index({ jobId: 1, tailorId: 1 }, { unique: true }); // one per tailor per job

module.exports = mongoose.model('Proposal', ProposalSchema);
