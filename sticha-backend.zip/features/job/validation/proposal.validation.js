const Joi = require('joi');

exports.create = Joi.object({
  quote:    Joi.number().positive().required(),
  duration: Joi.number().integer().min(1).required(),
  message:  Joi.string().max(2000).required()
});
