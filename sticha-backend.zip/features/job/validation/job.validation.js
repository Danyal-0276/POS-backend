const Joi = require('joi');

exports.create = Joi.object({
  title:       Joi.string().max(120).required(),
  description: Joi.string().max(5000).required(),
  categoryId:  Joi.string().hex().length(24).required(),
  budget:      Joi.number().positive(),
  dueDate:     Joi.date().greater('now'),
});

exports.update = Joi.object({
  title:       Joi.string().max(120),
  description: Joi.string().max(5000),
  categoryId:  Joi.string().hex().length(24),
  budget:      Joi.number().positive(),
  dueDate:     Joi.date().greater('now'),
  status:      Joi.string().valid('closed', 'cancelled')
}).min(1);
