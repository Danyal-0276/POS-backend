const Proposal = require('../model/Proposal');

class ProposalRepository {
  static create(doc) { return Proposal.create(doc); }

  static listByJob(jobId) {
    return Proposal.find({ jobId, deletedAt: { $exists: false } })
      .populate('tailorId')
      .sort({ createdAt: -1 })
      .lean()
      .exec();
  }

  static findById(id) { return Proposal.findById(id).lean().exec(); }

  static async findByTailorId(reqObj){
    let {tailorId , jobId} = reqObj;
    let results = "";
    results = await Proposal.find({tailorId : tailorId , jobId : jobId}).lean().exec();
    return results;

  }
  static update(id, upd) {
    return Proposal.findOneAndUpdate({ _id: id, deletedAt: { $exists: false } }, upd,
      { new: true, lean: true });
  }

  static rejectOtherProposals(jobId, acceptedId) {
    return Proposal.updateMany(
      { jobId, _id: { $ne: acceptedId }, deletedAt: { $exists: false } },
      { status: 'rejected' }
    );
  }
}

module.exports = ProposalRepository;
