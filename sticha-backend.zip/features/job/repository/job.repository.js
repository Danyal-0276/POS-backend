const Job = require('../model/Job');

class JobRepository {
  static create(doc)  { return Job.create(doc); }

  static list(filter, pagination) {
    return Job.find({ ...filter, deletedAt: { $exists: false } })
      .sort({ createdAt: -1 })
      .skip(pagination.skip)
      .limit(pagination.limit)
      .populate('categoryId customerId')
      .lean()
      .exec();
  }

  static count(filter) {
    return Job.countDocuments({ ...filter, deletedAt: { $exists: false } });
  }

  static async findById(id) {
    return Job.findOne({ _id: id, deletedAt: { $exists: false } }).lean().exec();
  }

  static update(id, upd) {
    return Job.findOneAndUpdate({ _id: id, deletedAt: { $exists: false } }, upd,
      { new: true, lean: true }).exec();
  }

  static softDelete(id) {
    return Job.findOneAndUpdate({ _id: id }, { deletedAt: new Date(), status: 'cancelled' });
  }
}

module.exports = JobRepository;
