const IdentityService = require('../../identity/service/identityService');
const identityService = require('../../identity/service/identityService')
const CustomerService = require('../../customer/service/customerProfileService');
const TailorService = require('../../tailor/service/tailorProfileService');
const { comparePassword, createToken } = require('../../../modules/helper');
const ApiError = require("../../../modules/ApiError");



class AuthService {


    static async signup(data) {

        try {

            const createdUser = await identityService.register(data);

            return {
                status: 200,
                message: "User Created",
                result: createdUser
            }

        } catch (error) {

            throw error;

        }

    }

    static async otpVerify(data) {
        try {

            let verifiedOtp = await IdentityService.verifyOtp(data);
            console.log(verifiedOtp);
            if (verifiedOtp === "OTP Expired") {
                return {
                    status: 404,
                    message: "Your one time password has been expired"
                }
            }
            return {
                status: 200,
                message: "OTP Verified"
            }
        } catch (error) {
            throw error;
        }

    }

    // static async login(data) {

    //     try {
    //         let { password, ...rest } = data
    //         let user = {};
    //         let results = "";
    //         let role = "";
    //         let result = await IdentityService.verifyIdentity(data);
    //         console.log()
    //         if (result !== null || result !== undefined) {
                
    //             let hashedpassword = result.password;
    //             role = result?.roleId?.name;
    //             let matchresult = await comparePassword(hashedpassword, password);
                
    //             let profileExists = false;
    //             try {
    //                 let data = await CustomerService.get(result._id);
    //                 console.log(data);
    //                 profileExists = true;
    //             } catch (err) {
    //                 if (!(err instanceof ApiError && err.status === 404)) throw err;
    //             }

    //             if (matchresult == "Ok") {
    //                 user = {
    //                     name: result.name,
    //                     email: result.email,
    //                     roleId: result.roleId,
    //                     _id: result._id
    //                 }
    //                 let usertoken = await createToken({ user });

    //                 if (usertoken) {
    //                     return {
    //                         status: 200,
    //                         message: "User Found",
    //                         result: { usertoken, role, profileExists: profileExists }
    //                     }
    //                 }

    //             } else {
    //                 return {
    //                     status: 404,
    //                     message: "Wrong Password"
    //                 }
    //             }
    //         } else {
    //             return {
    //                 status: 404,
    //                 message: "User Not Found"
    //             }
    //         }
    //     } catch (error) {
    //         throw error;
    //     }

    // }
    static async login(data) {
    try {
      const { email, password } = data || {};
      if (!email || !password) {
        return { status: 400, message: 'Email and password are required' };
      }

      const userDoc = await IdentityService.verifyIdentity({ email });
      if (!userDoc) {
        return { status: 404, message: 'User Not Found' };
      }

      const match = await comparePassword(userDoc.password, password);
      if (match !== 'Ok') {
        return { status: 404, message: 'Wrong Password' };
      }

      const role = userDoc?.roleId?.name?.toLowerCase();
      console.log(role);
      
      let profileExists = false;
      if (role === 'customer') {
        profileExists = await CustomerService.exists(userDoc._id);
      }else if(role === 'tailor'){
        console.log("here in tailor");
        profileExists = await TailorService.exists(userDoc._id);
        console.log(profileExists);
      }
      

      const user = {
        name: userDoc.name,
        email: userDoc.email,
        roleId: userDoc.roleId,
        _id: userDoc._id
      };

      const usertoken = await createToken({ user });
      return {
        status: 200,
        message: 'User Found',
        result: { usertoken, role, profileExists }
      };
    } catch (err) {
      throw err;
    }
  }

    static async resetPassword(data) {

        try {
            let result = "";
            let { email, old_password, new_password } = data;
            let user_result = await IdentityService.verifyPassword(data);
            if (user_result !== null) {
                let { password, ...rest } = user_result;
                let match = await comparePassword(password, old_password);
                if (match === "Ok") {

                    let newUserPassword = await IdentityService.updateUserPassword({ email, new_password });

                    if (newUserPassword) {
                        result = { status: 200, message: "Password Updated Successfully" }
                    } else {
                        result = { status: 500, message: "Internal error" }
                    }
                } else {
                    result = { status: 404, message: "Password Not Matched" }
                }

            } else {
                result = { status: 404, message: "User Not Found" }
            }

            return result;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

}

module.exports = {
    AuthService
}