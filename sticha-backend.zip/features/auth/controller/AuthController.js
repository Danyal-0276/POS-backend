const express = require('express');
const router = express.Router();
const logger = require('../../../modules/logger');
const { AuthService } = require('../service/authservice');
const asyncHandler = require('../../../middlewares/asyncHandler');


router.post('/register', asyncHandler(async (req, res) => {
  const result = await AuthService.signup(req.body);
  res.status(201).json(result);
}));

router.post('/verify/otp', asyncHandler(async (req, res) => {
  const result = await AuthService.otpVerify(req.body);
  res.json(result);
}));

router.post('/login', asyncHandler(async (req, res) => {
  const result = await AuthService.login(req.body);
  res.json(result);
}));

router.post('/reset-password', asyncHandler(async (req, res) => {
  const result = await AuthService.resetPassword(req.body);
  res.json(result);
}));



module.exports = router;
