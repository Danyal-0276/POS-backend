const Joi = require('joi');

exports.create = Joi.object({
  name:      Joi.string().trim().required(),
  parentId:  Joi.string().hex().length(24).allow(null, ''),
  icon:      Joi.any()                       // handled by Multer; kept for completeness
});

exports.update = Joi.object({
  name:      Joi.string().trim(),
  parentId:  Joi.string().hex().length(24).allow(null, ''),
  isActive:  Joi.boolean()
}).min(1);
