const express  = require('express');
const router   = express.Router();

const upload       = require('../../../middlewares/upload.middleware');
const validate     = require('../../../middlewares/validate.middleware');
const checkRoles   = require('../../../middlewares/rolecheck.middleware');
const schema       = require('../validation/category.validation');
const Service      = require('../service/categoryService');

/* ─────────────────────────────────────────
   PUBLIC  – anyone can list categories
───────────────────────────────────────── */
router.get('/', async (req, res, next) => {
  try {
    const list = await Service.list();
    res.json({ status: 200, result: list });
  } catch (e) { next(e); }
});

/* ─────────────────────────────────────────
   ADMIN-ONLY CRUD
───────────────────────────────────────── */
router.use(checkRoles('admin'));

/** CREATE */
router.post(
  '/',
  upload.avatarUpload,                 // reuse single-image helper
  validate(schema.create),
  async (req, res, next) => {
    try {
      const icon = req.file ? req.file.filename : null;
      const cat  = await Service.create(req.body, icon);
      res.status(201).json({ status: 201, result: cat });
    } catch (e) { next(e); }
  }
);

/** UPDATE */
router.put(
  '/:id',
  upload.avatarUpload,
  validate(schema.update),
  async (req, res, next) => {
    try {
      const icon     = req.file ? req.file.filename : null;
      const updated  = await Service.update(req.params.id, req.body, icon);
      res.json({ status: 200, result: updated });
    } catch (e) { next(e); }
  }
);

/** DELETE */
router.delete('/:id', async (req, res, next) => {
  try {
    await Service.remove(req.params.id);
    res.json({ status: 200, message: 'Category deleted' });
  } catch (e) { next(e); }
});

module.exports = router;
