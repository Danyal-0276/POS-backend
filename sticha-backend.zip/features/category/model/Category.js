'use strict';
const mongoose = require('mongoose');

const CategorySchema = new mongoose.Schema(
  {
    name:        { type: String, required: true, unique: true, trim: true },
    slug:        { type: String, required: true, unique: true },
    parentId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Category', default: null },
    icon:        { type: String, default: null },            // filename in /uploads
    isActive:    { type: Boolean, default: true },
    deletedAt:   { type: Date }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Category', CategorySchema);
