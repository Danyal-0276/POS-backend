const slugify  = require('slugify');
const Repo     = require('../repository/category.repository');
const { ApiError } = require('../../../modules/ApiError');

class CategoryService {
  static async create(body, icon) {
    const exists = await Repo.find({ name: body.name });
    if (exists.length) throw new ApiError(409, 'Category name already exists');

    const doc = {
      name: body.name,
      slug: slugify(body.name, { lower: true }),
      parentId: body.parentId || null,
      icon
    };

    return Repo.create(doc);
  }

  static list() {
    return Repo.find({ isActive: true });
  }

  static async update(id, body, icon) {
    if (body.name) body.slug = slugify(body.name, { lower: true });
    if (icon) body.icon = icon;

    const updated = await Repo.update(id, body);
    if (!updated) throw new ApiError(404, 'Category not found');
    return updated;
  }

  static async remove(id) {
    const cat = await Repo.softDelete(id);
    if (!cat) throw new ApiError(404, 'Category not found');
    return;
  }
}

module.exports = CategoryService;
