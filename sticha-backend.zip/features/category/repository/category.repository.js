const Category = require('../model/Category');

class CategoryRepository {
  static create(doc) {
    return Category.create(doc);
  }

  static find(query = {}) {
    return Category.find({ ...query, deletedAt: { $exists: false } }).lean().exec();
  }

  static findById(id) {
    return Category.findOne({ _id: id, deletedAt: { $exists: false } }).lean().exec();
  }

  static update(id, upd) {
    return Category.findOneAndUpdate(
      { _id: id, deletedAt: { $exists: false } },
      upd,
      { new: true, lean: true }
    ).exec();
  }

  static softDelete(id) {
    return Category.findOneAndUpdate({ _id: id }, { deletedAt: new Date(), isActive: false }).exec();
  }
}

module.exports = CategoryRepository;
