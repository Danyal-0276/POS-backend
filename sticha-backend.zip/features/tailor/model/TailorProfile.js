const mongoose = require('mongoose');

try {
    'use-strict';

    const TailrProfileSchema = new mongoose.Schema({

        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
            unique: true
        },

        profilePicture: { type: String },
        phone: { type: String },
        address: { type: String },

        geoLocation: {
            type: { type: String, enum: ['Point'], default: 'Point' },
            coordinates: { type: [Number] } // [lng, lat]
        },

        bio: { type: String },
        experience: { type: Number },
        specialization: [{ type: String }], // e.g. ['Suits', 'Dresses']

        portfolio: [{ type: String }], // Image URLs
        rating: { type: Number, default: 0 },
        reviewsCount: { type: Number, default: 0 },
         createdAt: {
            type: Date,
            default: Date.now
        },
        updatedAt: {
            type: Date,
            default: Date.now
        }
    });

    TailrProfileSchema.pre('save', function (next) {
        this.updatedAt = Date.now();
        next();
    })

    const TailorProfile = mongoose.model('TailorProfile' , TailrProfileSchema);
    module.exports = TailorProfile;

} catch (error) {
    console.log("error creating tailor model");
    throw error;
}