const express  = require('express');
const router   = express.Router();
const jwt = require('jsonwebtoken');
const upload       = require('../../../middlewares/upload.middleware');
const validate     = require('../../../middlewares/validate.middleware');
const parseJson    = require('../../../middlewares/parseJsonFields.middleware');
const checkRoles   = require('../../../middlewares/rolecheck.middleware');
const schema       = require('../validation/tailorProfile.validation');
const Service      = require('../service/tailorProfileService');
const asyncHandler = require('../../../middlewares/asyncHandler');
const { decode } = require('../../../modules/helper');

/* Tailor‑only access */


/** CREATE profile */
router.post(
  '/',
  checkRoles('tailor'),
  upload.profileUpload,
  parseJson(['geoLocation', 'specialization']),
  validate(schema.create),
  async (req, res, next) => {
    try {
      const avatar =
        req.files?.profilePicture?.[0]?.filename;

      const portfolio = (req.files?.portfolio || []).map(f => f.filename);

      const result = await Service.create(req?.user.user, req.body, avatar, portfolio);
      res.status(201).json({ status: 201, result });
    } catch (e) { next(e); }
  }
);

/** READ profile */
router.get('/',  checkRoles('tailor'), async (req, res, next) => {
  try {
    const token = req.headers['authorization']?.split(' ')[1];
    const user = jwt.decode(token);
    const userId = user?.user;
    console.log(userId);
    res.json({ status: 200, result: await Service.get(userId) });
  } catch (e) { next(e); }
});

/** UPDATE profile */
router.put(
  '/',
   checkRoles('tailor'),
  upload.profileUpload,
  parseJson(['geoLocation', 'specialization']),
  validate(schema.update),
  async (req, res, next) => {
    try {
      const avatar =
        req.files?.profilePicture?.[0]?.filename;
      const updated = await Service.update(req.user.user, req.body, avatar);
      res.json({ status: 200, result: updated });
    } catch (e) { next(e); }
  }
);

/** ADD portfolio images */
router.post(
  '/portfolio',
   checkRoles('tailor'),
  upload.portfolioUpload,
  async (req, res, next) => {
    try {
      const urls = (req.files || []).map(f => f.filename);
      const updated = await Service.addPortfolio(req.user.user, urls);
      res.json({ status: 200, result: updated });
    } catch (e) { next(e); }
  }
);

/** REMOVE one image */
router.delete('/portfolio',  checkRoles('tailor'),  async (req, res, next) => {
  try {
    const updated = await Service.removePortfolio(req.user.user, req.body.url);
    res.json({ status: 200, result: updated });
  } catch (e) { next(e); }
});


router.get('/profile/:id', asyncHandler(async (req, res) => {
  const result = await Service.getTailorProfile(req.params.id);
  res.status(201).json(result);
}));

module.exports = router;
