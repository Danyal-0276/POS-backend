const Joi = require('joi');

const geo = Joi.object({
  coordinates: Joi.array().items(Joi.number()).length(2).required()
});

exports.create = Joi.object({
  phone: Joi.string().required(),
  address: Joi.string().required(),
  geoLocation: geo.required(),
  bio: Joi.string().max(1000).required(),
  experience: Joi.number().integer().min(0).max(60).required(),
  specialization: Joi.array().items(Joi.string()).min(1).required()
});

exports.update = Joi.object({
  phone: Joi.string(),
  address: Joi.string(),
  geoLocation: geo,
  bio: Joi.string().max(1000),
  experience: Joi.number().integer().min(0).max(60),
  specialization: Joi.array().items(Joi.string()).min(1)
}).min(1);
