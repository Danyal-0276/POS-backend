const TailorProfile = require('../model/TailorProfile');

class TailorProfileRepository {
  static create(doc) { return TailorProfile.create(doc); }

  static findByUserId(userId) {
    return TailorProfile.findOne({ userId : userId }).lean().exec();
  }

  static async findById(userId){
    return TailorProfile.findOne({ userId : userId}).lean().exec();
  }

  static updateByUserId(userId, upd) {
    return TailorProfile.findOneAndUpdate({ userId }, upd, { new: true, lean: true }).exec();
  }

  static addPortfolioImage(userId, url) {
    return TailorProfile.findOneAndUpdate(
      { userId },
      { $push: { portfolio: url } },
      { new: true, lean: true }
    ).exec();
  }

  static removePortfolioImage(userId, url) {
    return TailorProfile.findOneAndUpdate(
      { userId },
      { $pull: { portfolio: url } },
      { new: true, lean: true }
    ).exec();
  }
    static findRaw(filter) {
    return TailorProfile.findOne(filter).lean().exec();
  }
}

module.exports = TailorProfileRepository;
