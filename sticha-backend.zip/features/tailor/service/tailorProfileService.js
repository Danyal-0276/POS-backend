const Repo       = require('../repository/tailorProfile.repository');
const ApiError = require('../../../modules/ApiError');

class TailorProfileService {
  static async create(userId, body, avatar, portfolio = []) {
    if (await Repo.findByUserId(userId))
      throw new ApiError(409, 'Profile already exists');

    const doc = { userId, ...body };
    if (avatar)      doc.profilePicture = avatar;
    if (portfolio.length) doc.portfolio      = portfolio;

    return Repo.create(doc);
  }

  static async get(userId) {
    
    const p = await Repo.findByUserId(userId);
    if (!p) throw new ApiError(404, 'Profile not found');
    return p;
  }

  static async update(userId, body, avatar) {
    if (avatar) body.profilePicture = avatar;
    const p = await Repo.updateByUserId(userId, body);
    if (!p) throw new ApiError(404, 'Profile not found');
    return p;
  }

  static async addPortfolio(userId, urls) {
    let last;
    for (const url of urls) last = await Repo.addPortfolioImage(userId, url);
    return last;
  }

  static removePortfolio(userId, url) {
    return Repo.removePortfolioImage(userId, url);
  }

 
  static async exists(userId) {
 
    const id = typeof userId === 'string' ? new mongoose.Types.ObjectId(userId) : userId;

 
    let doc = await Repo.findByUserId(id);


    if (!doc) {
      doc = await Repo.findRaw({ userId: String(id) });
    }

    if (!doc) {
      console.warn('[CustomerProfile.exists] not found for', { id, typeofId: typeof id });
    }
    return !!doc;
  }

  static async getTailorProfile(data){
    try {
        let results = "";
        console.log(data);
        if(data == null){
          return "Tailor Id is required";
        }
        results = await Repo.findById(data);
        return {status : 200 , message : "Tailor Found" , result : results};
    } catch (error) {
      throw error;
    }
  }
}

module.exports = TailorProfileService;
