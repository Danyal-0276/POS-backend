'use strict';
const mongoose  = require('mongoose');
const OrderRepo = require('../repository/order.repository');
const EscrowSvc = require('../../payment/service/escrow.service');
const redis     = require('../../../config/redis');
const ApiError  = require('../../../modules/ApiError');

const LIST_CACHE_TTL = 15; // seconds

class OrderService {
  // Create order after proposal acceptance, then create escrow & kick-off funding
  static async createFromProposal({ job, proposal, provider, customerEmail }) {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const deadline = new Date(Date.now() + proposal.duration * 864e5);

      const order = await OrderRepo.create({
        jobId: job._id,
        proposalId: proposal._id,
        customerId: job.customerId,
        tailorId: proposal.tailorId,
        quote: proposal.quote,               // cents
        duration: proposal.duration,
        deadline,
        status: 'pending_payment',
        paymentStatus: 'requires_payment'
      }, session);

      const escrow = await EscrowSvc.createForOrder({ order, provider, currency: 'usd' });
      await OrderRepo.update(order._id, { escrowId: escrow._id }, session);

      await session.commitTransaction();
      session.endSession();

      // Start funding:
      if (provider === 'stripe') {
        const { clientSecret } = await EscrowSvc.startCardFunding({ escrowId: escrow._id, customerEmail });
        return { orderId: order._id, escrowId: escrow._id, provider, clientSecret };
      }
      if (provider === 'coinbase') {
        const { hostedUrl } = await EscrowSvc.startCryptoFunding({ escrowId: escrow._id, customerEmail });
        return { orderId: order._id, escrowId: escrow._id, provider, hostedUrl };
      }
      throw new ApiError(400, 'Unsupported provider');
    } catch (err) {
      await session.abortTransaction(); session.endSession();
      throw err;
    }
  }

  static async list(user, role, pagination) {
    const key = `orders:${role}:${user._id}:${pagination.page}:${pagination.limit}`;
    const cache = await redis.get(key);
    if (cache) return JSON.parse(cache);

    const filter = role === 'tailor' ? { tailorId: user._id } :
                   role === 'customer' ? { customerId: user._id } : {};

    const [result, total] = await Promise.all([
      OrderRepo.list(filter, pagination),
      OrderRepo.count(filter)
    ]);

    await redis.setEx(key, LIST_CACHE_TTL, JSON.stringify({ total, result }));
    return { total, result };
  }

  static async deliver(orderId, tailorId, files) {
    const order = await OrderRepo.findById(orderId);
    if (!order || String(order.tailorId) !== String(tailorId)) throw new ApiError(404, 'Order not found');
    if (!['in_progress','revision'].includes(order.status))
      throw new ApiError(400, 'Cannot deliver at this stage');

    const urls = (files || []).map(f => f.filename);
    return OrderRepo.update(orderId, { status: 'delivered', deliveryUrls: urls });
  }

  static async acceptDelivery(orderId, customerId) {
    const order = await OrderRepo.findById(orderId);
    if (!order || String(order.customerId) !== String(customerId)) throw new ApiError(404, 'Order not found');
    if (order.status !== 'delivered') throw new ApiError(400, 'Order not delivered yet');
    if (!order.escrowId) throw new ApiError(400, 'Escrow not initialized');

    const esc = await EscrowSvc.release({ escrowId: order.escrowId });

    const feeAmount    = Math.floor((order.quote * (order.feeBps || 0)) / 10000);
    const payoutAmount = order.quote - feeAmount;

    return OrderRepo.update(orderId, {
      status: 'completed',
      paymentStatus: esc.status,
      feeAmount,
      payoutAmount
    });
  }

  static async requestRevision(orderId, customerId) {
    const order = await OrderRepo.findById(orderId);
    if (!order || String(order.customerId) !== String(customerId)) throw new ApiError(404, 'Order not found');
    if (order.status !== 'delivered') throw new ApiError(400, 'Revision allowed only after delivery');
    return OrderRepo.update(orderId, { status: 'revision', $inc: { revisionCount: 1 } });
  }

  static async cancelBeforePay(orderId, customerId) {
    const order = await OrderRepo.findById(orderId);
    if (!order || String(order.customerId) !== String(customerId)) throw new ApiError(404, 'Order not found');

    if (order.status !== 'pending_payment') throw new ApiError(400, 'Cancellation only before work starts');

    if (order.escrowId && ['processing','escrowed'].includes(order.paymentStatus)) {
      await EscrowSvc.refund({ escrowId: order.escrowId });
      return OrderRepo.update(orderId, { status: 'cancelled', paymentStatus: 'refunded' });
    }

    return OrderRepo.update(orderId, { status: 'cancelled' });
  }

  static async dispute(orderId, userId) {
    const order = await OrderRepo.findById(orderId);
    if (!order || (String(order.customerId) !== String(userId) && String(order.tailorId) !== String(userId)))
      throw new ApiError(404, 'Order not found');

    if (['completed','cancelled'].includes(order.status)) throw new ApiError(400, 'Cannot dispute at this stage');
    return OrderRepo.update(orderId, { status: 'disputed' });
  }
}

module.exports = OrderService;
