'use strict';
const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema(
  {
    jobId:        { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true, index: true },
    proposalId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Proposal', required: true, unique: true },
    customerId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    tailorId:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    quote:        { type: Number, required: true },   // cents
    duration:     { type: Number, required: true },   // days
    deadline:     { type: Date,   required: true },

    status: {
      type: String,
      enum: ['pending_payment','in_progress','delivered','revision','completed','cancelled','disputed'],
      default: 'pending_payment',
      index: true
    },

    paymentStatus: {
      type: String,
      enum: ['requires_payment','processing','escrowed','released','refunded','failed','pending_manual_payout'],
      default: 'requires_payment',
      index: true
    },

    escrowId:     { type: mongoose.Schema.Types.ObjectId, ref: 'Escrow' },

    deliveryUrls: [String],
    revisionCount:{ type: Number, default: 0 },

    feeBps:       { type: Number, default: Number(process.env.PLATFORM_FEE_BPS || 0) },
    feeAmount:    { type: Number, default: 0 },
    payoutAmount: { type: Number, default: 0 },

    deletedAt:    { type: Date }
  },
  { timestamps: true }
);

OrderSchema.index({ tailorId: 1, status: 1, createdAt: -1 });

module.exports = mongoose.model('Order', OrderSchema);
