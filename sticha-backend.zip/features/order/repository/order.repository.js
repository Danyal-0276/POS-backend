const Order = require('../model/Order');

class OrderRepository {
  static create(doc, session)  { return Order.create([doc], { session }).then(r => r[0]); }

  static list(filter, pagination) {
    return Order.find({ ...filter, deletedAt: { $exists: false } })
      .sort({ createdAt: -1 })
      .skip(pagination.skip)
      .limit(pagination.limit)
      .lean()
      .exec();
  }

  static count(filter) { return Order.countDocuments({ ...filter, deletedAt: { $exists: false } }); }

  static findById(id)  { return Order.findOne({ _id: id, deletedAt: { $exists: false } }).lean().exec(); }

  static update(id, upd, session = null) {
    return Order.findOneAndUpdate(
      { _id: id, deletedAt: { $exists: false } }, upd,
      { new: true, lean: true, session });
  }

  static softDelete(id) { return Order.findOneAndUpdate({ _id: id }, { deletedAt: new Date() }); }
}

module.exports = OrderRepository;
