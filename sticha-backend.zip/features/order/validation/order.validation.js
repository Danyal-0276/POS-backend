const Joi = require('joi');

exports.createFromProposal = Joi.object({
  jobId:      Joi.string().required(),
  proposalId: Joi.string().required(),
  provider:   Joi.string().valid('stripe','coinbase').required()
});

exports.deliver = Joi.object({
  message:  Joi.string().max(2000).required()
}).unknown();  // allow multer files

exports.requestRevision = Joi.object({
  message: Joi.string().max(2000).required()
});
