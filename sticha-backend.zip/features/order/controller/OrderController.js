const express  = require('express');
const router   = express.Router();

const upload       = require('../../../middlewares/upload.middleware');
const paginate     = require('../../../middlewares/pagination.middleware');
const validate     = require('../../../middlewares/validate.middleware');
const checkRoles   = require('../../../middlewares/rolecheck.middleware');
const oVal         = require('../validation/order.validation');
const Service      = require('../service/orderService');

// LIST mine
router.get('/mine',
  paginate(),
  async (req, res, next) => {
    try {
      const role = req.user.role || req.user?.user?.role; // depends how you set token
      const data = await Service.list(req.user.user || req.user, role, req.pagination);
      res.json({ status: 200, ...data });
    } catch (e) { next(e); }
  }
);

// Create order from proposal + init escrow funding
router.post('/from-proposal',
  checkRoles('customer'),
  validate(oVal.createFromProposal),
  async (req, res, next) => {
    try {
      const { jobId, proposalId, provider } = req.body;

      // You likely already have JobRepo/PropRepo; import if needed
      const JobRepo  = require('../../job/repository/job.repository');
      const PropRepo = require('../../job/repository/proposal.repository');

      const job      = await JobRepo.getById(jobId);
      const proposal = await PropRepo.getById(proposalId);
      if (!job || !proposal) return res.status(404).json({ status: 404, message: 'Job or proposal not found' });
      if (String(job.customerId) !== String((req.user.user || req.user)._id))
        return res.status(403).json({ status: 403, message: 'Not your job' });
      if (String(proposal.jobId) !== String(job._id))
        return res.status(400).json({ status: 400, message: 'Proposal does not belong to the job' });

      const email = (req.user.user || req.user).email;
      const result = await Service.createFromProposal({ job, proposal, provider, customerEmail: email });
      res.status(201).json({ status: 201, result });
    } catch (e) { next(e); }
  }
);

// Tailor deliver
router.post('/:id/deliver',
  checkRoles('tailor'),
  upload.array('files', 10),
  validate(oVal.deliver),
  async (req, res, next) => {
    try {
      const ord = await Service.deliver(req.params.id, (req.user.user || req.user)._id, req.files);
      res.json({ status: 200, result: ord });
    } catch (e) { next(e); }
  }
);

// Customer accept delivery (release escrow)
router.post('/:id/accept',
  checkRoles('customer'),
  async (req, res, next) => {
    try {
      const ord = await Service.acceptDelivery(req.params.id, (req.user.user || req.user)._id);
      res.json({ status: 200, result: ord });
    } catch (e) { next(e); }
  }
);

// Request revision
router.post('/:id/request-revision',
  checkRoles('customer'),
  validate(oVal.requestRevision),
  async (req, res, next) => {
    try {
      const ord = await Service.requestRevision(req.params.id, (req.user.user || req.user)._id);
      res.json({ status: 200, result: ord });
    } catch (e) { next(e); }
  }
);

// Cancel before payment
router.post('/:id/cancel',
  checkRoles('customer'),
  async (req, res, next) => {
    try {
      await Service.cancelBeforePay(req.params.id, (req.user.user || req.user)._id);
      res.json({ status: 200, message: 'Order cancelled' });
    } catch (e) { next(e); }
  }
);

// Dispute
router.post('/:id/dispute',
  async (req, res, next) => {
    try {
      const ord = await Service.dispute(req.params.id, (req.user.user || req.user)._id);
      res.json({ status: 200, result: ord });
    } catch (e) { next(e); }
  }
);

module.exports = router;
