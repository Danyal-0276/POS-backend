const User = require('../model/User');
const ApiError = require('../../../modules/ApiError');

class UserRepository{

   static async create(data) {
    try {
      return await User.create(data);
    } catch (err) {
      // Mongo duplicate key error
      if (err?.code === 11000 || (err?.name === 'MongoServerError' && err?.keyPattern)) {
        throw new ApiError(409, 'user already exists');
      }
      // Mongoose validation error (nice to have)
      if (err?.name === 'ValidationError') {
        const first = Object.values(err.errors || {})[0];
        throw new ApiError(400, first?.message || 'validation error');
      }
      throw err;
    }
  }
    static async get(){
       return await User.find().exec();
    }

    static async getById(data){
        return await User.findById(data).exec();
    }
    static async markemail(data){
        
       return await User.findOneAndUpdate({email : data} , {isEmailVerified : true} , {new : true}).exec();
       
    }
    static async findUserDetails(data){
        return await User.findOne(data).populate('roleId').exec();
    }

    static async updateUserPassword(data){
        return await User.findOneAndUpdate({email : data.email} , {password : data.hashpassword} , {new : true}).exec();
    }
    

}

module.exports = {
    UserRepository
}