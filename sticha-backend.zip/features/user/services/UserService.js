const { UserRepository } = require("../repository/user.repository");



class UserService{

    static async addUser(data){

        try {
            let result = await UserRepository.create(data);
            return result;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }

    static async markEmailVerified(data){

        try {
            
        
            let result = await UserRepository.markemail(data);
            console.log(result);
            if(result !== undefined || result !== null){
                return result;
            }
        } catch (error) {
            throw error;
        }
    }

    static async findUser(data){

         try {
            let obj = {}
            let result = "";

            if(data.email){
                obj.email = data.email
            }

            if(data.name){
                obj.name = data.name
            }

             result = await UserRepository.findUserDetails(obj)
             return result;

        } catch (error) {
            throw error;
        }
    }

    static async updatePassword(data){
        try {
            let result = "";
            let userData = await UserRepository.updateUserPassword(data);
            return userData;
        } catch (error) {
            console.log(error);
            throw error;
        }
    }
    

}

module.exports = {
    UserService
}