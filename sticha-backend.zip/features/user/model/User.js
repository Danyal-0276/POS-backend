const { lowerCase } = require('lodash');
const mongoose = require('mongoose');
try {
    'use-strict';
    const UserSchema = new mongoose.Schema({


        name: {
            type: String,
            required: true,
            trim: true
        },
        email: {
            type: String,
            required: true,
          
            lowercase: true,
            trim: true
        },
        password: {
            type: String,
            required: true,
            trim: true
        },

        roleId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Role',
            required: true
        },
        isEmailVerified: {
            type: Boolean,
            default: false
        },
        is2FA: {
            type: Boolean,
            default: false
        },
        isActive: {
            type: Boolean,
            default: false
        },

        twoFAMethod: {
            type: String,
            enum: ['app', 'sms', 'email'],
            default: 'email'
        },
        createdAt: {
            type: Date,
            default: Date.now
        },
        updatedAt: {
            type: Date,
            default: Date.now
        }
    });

    UserSchema.pre('save', function (next) {
        this.updatedAt = Date.now();
        next();
    })
    UserSchema.index({ email: 1 }, { unique: true });


    const User = mongoose.model('User', UserSchema);

    module.exports = User;
} catch (error) {
    console.error('Error creating the User schema:', error);
}
