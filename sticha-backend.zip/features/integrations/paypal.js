'use strict';
const paypal = require('@paypal/checkout-server-sdk');

const env = process.env.PAYPAL_ENV === 'live'
  ? new paypal.core.LiveEnvironment(
      process.env.PAYPAL_CLIENT_ID,
      process.env.PAYPAL_CLIENT_SECRET)
  : new paypal.core.SandboxEnvironment(
      process.env.PAYPAL_CLIENT_ID,
      process.env.PAYPAL_CLIENT_SECRET);

const client = new paypal.core.PayPalHttpClient(env);

/* Helper – amounts always in USD for now */
const buildAmount = (amount) => ({
  currency_code: 'USD',
  value: amount.toFixed(2)
});

module.exports = {
  /** Create an order intent – returns { id, approvalUrl } */
  async createOrder(amount, currency = 'USD') {
    const request = new paypal.orders.OrdersCreateRequest();
    request.prefer('return=representation');
    request.requestBody({
      intent: 'CAPTURE',
      purchase_units: [{
        amount: buildAmount(amount),
      }]
    });

    const response = await client.execute(request);
    const approval = response.result.links.find(l => l.rel === 'approve');
    return { id: response.result.id, approvalUrl: approval.href };
  },

  /** Capture (charge) an approved order */
  async captureOrder(id) {
    const request = new paypal.orders.OrdersCaptureRequest(id);
    request.requestBody({});
    return client.execute(request);      // throws if fails
  },

  /** Refund (full) – NB: PayPal requires capture ID, not order ID */
  async refundOrder(captureId, amount) {
    const req = new paypal.payments.CapturesRefundRequest(captureId);
    req.requestBody({ amount: buildAmount(amount) });
    return client.execute(req);
  }
};
