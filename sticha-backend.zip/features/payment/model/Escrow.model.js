'use strict';
const mongoose  = require('mongoose');

const EscrowSchema = new mongoose.Schema({
  orderId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true, index: true },
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User',  required: true, index: true },
  tailorId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User',  required: true, index: true },

  provider:   { type: String, enum: ['stripe', 'coinbase'], required: true },
  currency:   { type: String, default: 'usd' },
  amount:     { type: Number, required: true, min: 1 }, // cents

  paymentIntentId: { type: String },  // Stripe
  chargeId:        { type: String },  // Coinbase Commerce
  transferId:      { type: String },  // Stripe transfer on release
  refundId:        { type: String },  // Stripe refund

  status: {
    type: String,
    enum: ['requires_payment','processing','escrowed','released','refunded','failed','disputed','pending_manual_payout'],
    default: 'requires_payment',
    index: true
  },

  events: [{
    type: { type: String },
    at:   { type: Date, default: Date.now },
    meta: { type: mongoose.Schema.Types.Mixed }
  }]
}, { timestamps: true });

module.exports = mongoose.model('Escrow', EscrowSchema);
