'use strict';
const stripeProvider   = require('../provider/stripe.provider');
const coinbaseProvider = require('../provider/coinbase.provider');

module.exports = {
  byName(name) {
    if (name === 'stripe') return stripeProvider;
    if (name === 'coinbase') return coinbaseProvider;
    throw new Error('Unknown payment provider: ' + name);
  },
  stripe: stripeProvider,
  coinbase: coinbaseProvider
};
