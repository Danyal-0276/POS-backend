'use strict';
const Stripe   = require('stripe');
const ApiError = require('../../../modules/ApiError');
const stripe   = new Stripe(process.env.STRIPE_SECRET_KEY);

module.exports = {
  async createIntent({ amount, currency, escrowId, customerEmail }) {
    const intent = await stripe.paymentIntents.create({
      amount,
      currency,
      automatic_payment_methods: { enabled: true },
      metadata: { escrowId },
      receipt_email: customerEmail
    });
    return { clientSecret: intent.client_secret, intentId: intent.id };
  },

  async transferToTailor({ amount, currency, stripeAccountId, escrowId }) {
    if (!stripeAccountId) return { pendingManual: true };
    const transfer = await stripe.transfers.create({
      amount, currency, destination: stripeAccountId, metadata: { escrowId }
    });
    return { transferId: transfer.id };
  },

  async refund({ paymentIntentId, amount }) {
    const intent = await stripe.paymentIntents.retrieve(paymentIntentId, { expand: ['charges'] });
    const chargeId = intent.charges?.data?.[0]?.id;
    if (!chargeId) throw new ApiError(400, 'No charge found to refund');
    const refund = await stripe.refunds.create({ charge: chargeId, amount });
    return { refundId: refund.id };
  }
};
