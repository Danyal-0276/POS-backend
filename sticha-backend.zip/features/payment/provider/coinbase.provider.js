'use strict';
const coinbase = require('coinbase-commerce-node');
const Client   = coinbase.Client;
const Charge   = coinbase.resources.Charge;

Client.init(process.env.COINBASE_API_KEY);

module.exports = {
  async createCharge({ amount, currency, escrowId, orderId, customerEmail }) {
    const charge = await Charge.create({
      name: 'STICHA Order Funding',
      description: `Funding order ${orderId}`,
      local_price: { amount: (amount / 100).toFixed(2), currency },
      pricing_type: 'fixed_price',
      metadata: { escrowId, orderId, customerEmail }
    });
    return { chargeId: charge.id, hostedUrl: charge.hosted_url };
  }
};
