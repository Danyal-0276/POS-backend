'use strict';
const express       = require('express');
const router        = express.Router();
const EscrowService = require('../service/escrow.service');
const ApiError      = require('../../../modules/ApiError');

// STRIPE
router.post('/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
  const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (e) {
    throw new ApiError(400, `Stripe webhook verify failed: ${e.message}`);
  }

  if (event.type === 'payment_intent.succeeded') {
    const escrowId = event.data.object?.metadata?.escrowId;
    if (escrowId) await EscrowService.markEscrowed(escrowId, { stripeEventId: event.id });
  }
  res.json({ received: true });
});

// COINBASE
router.post('/coinbase', express.raw({ type: 'application/json' }), async (req, res) => {
  const cb = require('coinbase-commerce-node');
  const Webhook = cb.Webhook;
  let event;
  try {
    event = Webhook.verifyEventBody(
      req.body.toString('utf8'),
      req.headers['x-cc-webhook-signature'],
      process.env.COINBASE_WEBHOOK_SECRET
    );
  } catch (e) {
    throw new ApiError(400, `Coinbase webhook verify failed: ${e.message}`);
  }

  if (event.type === 'charge:confirmed') {
    const escrowId = event.data?.metadata?.escrowId;
    if (escrowId) await EscrowService.markEscrowed(escrowId, { coinbaseEventId: event.id });
  }
  res.json({ received: true });
});

module.exports = router;
