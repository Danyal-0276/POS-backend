'use strict';
const express  = require('express');
const router   = express.Router();
const EscrowService = require('../service/escrow.service');
const ApiError      = require('../../../modules/ApiError');
const checkRoles    = require('../../../middlewares/rolecheck.middleware');

const Order = require('../../order/model/Order');

// Create or fetch escrow for an order
router.post('/escrow/:orderId/init', checkRoles('customer'), async (req, res) => {
  const order = await Order.findById(req.params.orderId).lean();
  if (!order) throw new ApiError(404, 'Order not found');

  const me = String((req.user.user || req.user)._id);
  if (String(order.customerId) !== me) throw new ApiError(403, 'Not your order');

  const provider = (req.body.provider || 'stripe').toLowerCase();
  const esc = await EscrowService.createForOrder({ order, provider, currency: 'usd' });
  res.json({ status: 200, result: esc });
});

// Stripe card funding
router.post('/escrow/:escrowId/fund/card', checkRoles('customer'), async (req, res) => {
  const email = (req.user.user || req.user).email;
  const { clientSecret, escrowId } = await EscrowService.startCardFunding({
    escrowId: req.params.escrowId, customerEmail: email
  });
  res.json({ status: 200, result: { escrowId, clientSecret } });
});

// Crypto funding
router.post('/escrow/:escrowId/fund/crypto', checkRoles('customer'), async (req, res) => {
  const email = (req.user.user || req.user).email;
  const { hostedUrl, escrowId } = await EscrowService.startCryptoFunding({
    escrowId: req.params.escrowId, customerEmail: email
  });
  res.json({ status: 200, result: { escrowId, hostedUrl } });
});

// Release (rarely needed here because we release on accept)
// Kept for admin/manual flows
router.post('/escrow/:escrowId/release', checkRoles('customer'), async (req, res) => {
  const esc = await EscrowService.release({ escrowId: req.params.escrowId });
  res.json({ status: 200, result: esc });
});

// Refund (before release)
router.post('/escrow/:escrowId/refund', checkRoles('customer'), async (req, res) => {
  const esc = await EscrowService.refund({ escrowId: req.params.escrowId });
  res.json({ status: 200, result: esc });
});

module.exports = router;
