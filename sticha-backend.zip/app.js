// server.js (entrypoint)
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const logger = require('./modules/logger');

const { routes } = require('./config/Routes');
const initSwagger = require('./config/swagger');
const { Base } = require('./middlewares/Base');
const errorLogger = require('./middlewares/errorLoggingMiddleware'); 
const errorConverter = require('./middlewares/errorConverter');
const errorHandler = require('./middlewares/errorHandler.middleware');
const webhookRouter = require('./features/payment/controller/Webhook.Controller');


const app = express();

app.use(helmet());
app.use(
  cors({
    origin: '*',
    methods: 'GET,POST,PUT,DELETE,OPTIONS',
    allowedHeaders: 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
  })
);
app.options('*', cors());
app.use('/webhooks', webhookRouter);  // raw body


Base.init(app).then(() => {
 
  routes(app);
  initSwagger(app);


  const ApiError = require('./modules/ApiError');
  app.use((req, res, next) => next(new ApiError(404, 'Not Found')));

 
  app.use(errorLogger);  
  app.use(errorConverter); 
  app.use(errorHandler);  


  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log('Server running on port', PORT));
});


process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', { message: err.message, stack: err.stack });
  process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Rejection:', {
    reason: reason?.message || String(reason),
    stack: reason?.stack,
  });
  process.exit(1);
});
