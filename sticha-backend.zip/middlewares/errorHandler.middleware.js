// middlewares/errorHandler.middleware.js
module.exports = (err, req, res, next) => {
  const status = Number(err.status) || 500;
  const message = err.message || 'Internal Server Error';
  res.status(status).json({ status, message });
};
