// middlewares/errorHandler.js
module.exports = function errorHandler(err, req, res, next) {
  const status = Number(err.status) || 500;
  const payload = {
    status,
    message: err.message || 'Internal Server Error',
  };

  // include meta for client-side field errors, etc. (optional)
  if (err.meta) payload.meta = err.meta;

  // include stack only in non-prod (optional)
  if (process.env.NODE_ENV !== 'production' && err.stack) {
    payload.stack = err.stack;
  }

  res.status(status).json(payload);
};
