// middlewares/errorConverter.js
const ApiError = require('../modules/ApiError');

module.exports = (err, req, res, next) => {
  if (err instanceof ApiError) return next(err);

  if (err?.code === 11000 || (err?.name === 'MongoServerError' && err?.keyPattern)) {
    const field = Object.keys(err.keyPattern || {})[0] || 'resource';
    return next(new ApiError(409, `${field} already exists`));
  }

  if (err?.name === 'ValidationError') {
    const first = Object.values(err.errors || {})[0];
    return next(new ApiError(400, first?.message || 'validation error'));
  }

  if (err?.name === 'CastError') {
    return next(new ApiError(400, `invalid ${err.path}`));
  }

  next(new ApiError(Number(err?.status) || 500, err?.message || 'Internal Server Error'));
};
