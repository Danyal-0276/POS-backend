const { findLastKey } = require('lodash');
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        minlength: 3,
        maxlength: 30
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        match: [/^\S+@\S+\.\S+$/, 'Please use a valid email address.']
    },
    password: {
        type: String,
        minlength: 6
    },
    isEmailVerified : {
        type : Boolean,
        default : false
    },
    isActive : {
        type : Boolean,
        default : true
    },
    enable2FA : {
        type : Boolean,
        default : false
    },
    RoleId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Role'
    },
   
    createdAt: {
        type: Date,
        default: Date.now
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: false // Optional for clients/vendors
    },        
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

UserSchema.pre('save', function (next) {
    this.updatedAt = Date.now();
    next();
});

const User = mongoose.model('User', UserSchema);

module.exports = User;
