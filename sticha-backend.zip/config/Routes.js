'use strict';
const routes = (app) => {
    app.use('/role', require('../features/role/controller/RoleController'));
    app.use('/auth' , require('../features/auth/controller/AuthController'));
    app.use('/customer/profile', require('../features/customer/controller/CustomerProfileController'));
    app.use('/tailor/profile', require('../features/tailor/controller/TailorProfileController'));
    app.use('/categories', require('../features/category/controller/CategoryController'));
    app.use('/jobs', require('../features/job/controller/JobController'));
    app.use('/orders',   require('../features/order/controller/OrderController'));
  app.use('/payments', require('../features/payment/controller/PaymentController'));
    





};

module.exports = {
    routes
};
